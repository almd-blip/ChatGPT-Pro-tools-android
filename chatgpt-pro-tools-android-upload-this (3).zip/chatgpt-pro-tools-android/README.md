# ChatGPT Pro Tools for Android

An Android equivalent of the [ChatGPT Pro Tools](https://gptprotools.com/) Chrome extension. It wraps ChatGPT in a full-screen WebView and adds a slide-out **Chat Manager** for searching, tagging, filtering, and exporting long AI conversations.

## What it does

- **Full-screen ChatGPT WebView** — loads `https://chatgpt.com/` with a desktop Chrome user agent so you get the full web UI on Android.
- **Chat Manager side panel** — swipe/click the ☰ menu to open a full-screen panel with:
  - Full-text search across titles and preview text.
  - Tag filters.
  - Date range filters.
  - AI-powered tag generation (offline keyword heuristic by default, pluggable MediaPipe LLM).
  - Per-chat export to **Markdown**, **TXT**, or **PDF**.
- **JavaScript bridge** — extracts the conversation list and current chat from the ChatGPT page so the Chat Manager can index it.

## Project structure

```
chatgpt-pro-tools-android/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/gptprotools/
│       │   ├── ai/
│       │   │   └── AiTagger.kt            # On-device / heuristic AI tagging
│       │   ├── bridge/
│       │   │   └── JavaScriptBridge.kt    # WebView ↔ Android bridge + injected JS
│       │   ├── export/
│       │   │   └── ExportUtils.kt         # MD / TXT / PDF export
│       │   ├── model/
│       │   │   └── Chat.kt                # Chat data model & in-memory repository
│       │   └── ui/
│       │       ├── MainActivity.kt
│       │       ├── WebViewScreen.kt       # ChatGPT WebView wrapper
│       │       ├── ChatManagerPanel.kt    # Slide-out Chat Manager UI
│       │       ├── ChatManagerViewModel.kt
│       │       └── theme/                 # Compose theme
│       └── res/...
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── gradlew
├── gradlew.bat
└── README.md
```

## How to build (no coding required)

If you don't want to install Android Studio or write code, you can let GitHub build the APK for you automatically.

### Option A: Build with GitHub Actions (recommended for non-coders)

1. **Create a free GitHub account** at [github.com](https://github.com).
2. **Create a new repository** (e.g., `chatgpt-pro-tools-android`). Leave it empty.
3. **Download `chatgpt-pro-tools-android.zip`** from this workspace.
4. In your new GitHub repository, tap **uploading an existing file** and select `chatgpt-pro-tools-android-upload-this.zip`. Do **not** extract it first—upload the ZIP as-is.
5. Tap **Commit changes**.
6. Go to the **Actions** tab of your repository.
7. GitHub will automatically start a workflow called **Build Android APK from ZIP**. Wait a few minutes.
8. When it finishes, click the workflow run, scroll down to **Artifacts**, and download `app-debug-apk`.
9. Extract the ZIP and install `app-debug.apk` on your Samsung tablet.

The workflow file is already included at `.github/workflows/build.yml`. It extracts the ZIP, builds the APK, and makes it available for download.

**If the workflow does not start automatically**, go to **Actions** → **Build Android APK from ZIP** → **Run workflow**.

### Option B: Build on a computer

1. Open **Android Studio** (Ladybug or newer recommended).
2. Choose **Open** and select the `chatgpt-pro-tools-android` folder.
3. Let Android Studio sync the project.
4. Run on an emulator or device with **Android 8+** (API 26).

Command line alternative:

```bash
cd chatgpt-pro-tools-android
./gradlew assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## How to use

1. Launch the app.
2. Log into ChatGPT in the WebView if you are not already.
3. Tap the ☰ menu in the top-left to open the **Chat Manager**.
4. Wait a moment while the app scans the sidebar conversations.
5. Use search, tags, or date filters to find the chat you need.
6. Tap **AI Tag All** to automatically tag conversations based on their content (keyword heuristic by default).
7. Tap **Export** on any chat to save it as Markdown, TXT, or PDF.

## Important limitations

Because this is a **WebView wrapper** rather than an official integration, some things are inherently fragile:

- **ChatGPT DOM extraction is best-effort.** ChatGPT updates its web app frequently. The injected JavaScript tries to read the sidebar links and conversation `article` elements, but selectors may break over time. The fallback is manual tag management.
- **Chat navigation is implemented.** Tapping a chat in the Chat Manager tries to click the matching sidebar link or falls back to navigating to `https://chatgpt.com/c/<id>`. This depends on the ChatGPT DOM structure and may break if it changes.
- **Deleting a chat only removes it from the local Chat Manager list.** It does not delete the conversation on ChatGPT itself.
- **Export quality depends on what the JS bridge captures.** If the current chat is not fully loaded when you export, the result may be truncated.
- **Play Store policy:** Wrapping an existing web service as a standalone app can violate Google Play policies. This project is intended as a personal/utility prototype, not a store-ready product, without written permission from OpenAI.

## Enabling real on-device AI tagging

The default tagger uses a lightweight, fully offline keyword heuristic. To use a real on-device LLM (e.g., Gemma 2B via MediaPipe):

1. Uncomment the MediaPipe dependency in `app/build.gradle.kts`:
   ```kotlin
   implementation("com.google.mediapipe:tasks-genai:0.10.14")
   ```
2. Download a small instruction-tuned model such as **Gemma 2B IT** (`.bin` format) from Kaggle or Hugging Face.
3. Place the model file in the device storage and update the `modelPath` in `AiTaggerFactory.create()` (see `ai/AiTagger.kt` for the commented example).
4. Rebuild and run.

If your device supports **Gemini Nano** (Pixel 9 Pro, Pixel 8 Pro with AICore, etc.), you can also plug in the Android AICore API in `AiTaggerFactory`.

## Roadmap / possible next steps

- Bulk select / archive / pin chats.
- Prompt manager (save reusable templates with variables).
- Copy full conversation to clipboard.
- Import chat history JSON exported from ChatGPT settings as a fallback data source.
- Add a non-WebView mode that uses the OpenAI API for users who prefer API-based chat management.

## License

This is a prototype/demonstration project. Use at your own risk. ChatGPT is a trademark of OpenAI. This project is not affiliated with or endorsed by OpenAI.
