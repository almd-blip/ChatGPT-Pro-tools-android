package com.gptprotools.bridge

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.gptprotools.model.Chat
import com.gptprotools.model.ChatMessage
import com.gptprotools.model.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * JavaScript bridge between the ChatGPT WebView and the Android app.
 */
class JavaScriptBridge(
    private val onConversationsLoaded: () -> Unit,
    private val onError: (String) -> Unit
) {
    private val _conversations = MutableStateFlow<List<Chat>>(emptyList())
    val conversations: StateFlow<List<Chat>> = _conversations

    private val dateParser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())

    @JavascriptInterface
    fun receiveConversationList(json: String) {
        try {
            val array = JSONArray(json)
            val chats = List(array.length()) { i ->
                val obj = array.getJSONObject(i)
                val id = obj.optString("id").ifEmpty { obj.optString("href") }
                val title = obj.optString("title").ifEmpty { "Untitled chat" }
                val preview = obj.optString("preview")
                val updated = parseDate(obj.optString("updatedAt"))
                Chat(
                    externalId = id,
                    title = title,
                    previewText = preview,
                    updatedAt = updated,
                    createdAt = updated,
                    messages = emptyList()
                )
            }
            ChatRepository.setAll(chats)
            _conversations.value = chats
            onConversationsLoaded()
        } catch (e: Exception) {
            onError("Failed to parse conversation list: ${e.message}")
        }
    }

    @JavascriptInterface
    fun receiveCurrentConversation(json: String) {
        try {
            val obj = JSONObject(json)
            val id = obj.optString("id")
            val title = obj.optString("title").ifEmpty { "Untitled chat" }
            val messages = parseMessages(obj.optString("messages", "[]"))
            val chat = Chat(
                externalId = id,
                title = title,
                previewText = messages.lastOrNull()?.text?.take(200) ?: "",
                updatedAt = Date(),
                messages = messages
            )
            ChatRepository.addOrUpdate(chat)
            onConversationsLoaded()
        } catch (e: Exception) {
            onError("Failed to parse current conversation: ${e.message}")
        }
    }

    @JavascriptInterface
    fun log(message: String) {
        android.util.Log.d("GPTProTools", message)
    }

    @JavascriptInterface
    fun reportError(message: String) {
        onError(message)
    }

    fun scanConversationList(webView: WebView) {
        webView.evaluateJavascript(EXTRACT_CONVERSATION_LIST) { }
    }

    fun scanCurrentConversation(webView: WebView) {
        webView.evaluateJavascript(EXTRACT_CURRENT_CONVERSATION) { }
    }

    fun navigateToChat(webView: WebView, chatId: String) {
        val script = """
            (function() {
                try {
                    const link = document.querySelector('a[href="/c/${chatId}"]');
                    if (link) { link.click(); }
                    else { window.location.href = '/c/${chatId}'; }
                } catch (e) {
                    window.location.href = '/c/${chatId}';
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(script) { }
    }

    private fun parseMessages(json: String): List<ChatMessage> {
        val array = JSONArray(json)
        return List(array.length()) { i ->
            val obj = array.getJSONObject(i)
            ChatMessage(
                role = obj.optString("role", "unknown"),
                text = obj.optString("text", "")
            )
        }
    }

    private fun parseDate(value: String?): Date {
        if (value.isNullOrEmpty()) return Date()
        return try {
            dateParser.parse(value) ?: Date()
        } catch (e: Exception) {
            Date()
        }
    }
}

/**
 * JavaScript injected into the ChatGPT WebView to read the conversation list.
 * ChatGPT's DOM changes over time; this is a best-effort extraction.
 */
const val EXTRACT_CONVERSATION_LIST = """
(function() {
    try {
        const links = Array.from(document.querySelectorAll('a[href^="/c/"]'));
        const items = links.map(a => {
            const title = a.querySelector('div, span')?.innerText?.trim() || a.innerText?.trim() || '';
            const href = a.getAttribute('href') || '';
            const id = href.split('/c/')[1]?.split('/')[0] || href;
            let updatedAt = '';
            const parent = a.closest('li, div.group');
            if (parent) {
                const time = parent.querySelector('time');
                if (time) updatedAt = time.getAttribute('datetime') || '';
            }
            return JSON.stringify({ id: id, title: title, preview: title, href: href, updatedAt: updatedAt });
        });
        GPTProTools.receiveConversationList('[' + items.join(',') + ']');
    } catch (e) {
        GPTProTools.reportError('List extraction failed: ' + e.message);
    }
})();
"""

/**
 * JavaScript injected to read the currently open conversation.
 */
const val EXTRACT_CURRENT_CONVERSATION = """
(function() {
    try {
        const id = window.location.pathname.split('/c/')[1]?.split('/')[0] || '';
        let title = document.title.replace(' - ChatGPT', '').trim();
        if (!title) title = document.querySelector('h1, h2')?.innerText?.trim() || 'Untitled chat';
        const articleSelector = 'article[data-testid^="conversation-turn-"], main article';
        const articles = Array.from(document.querySelectorAll(articleSelector));
        const messages = articles.map(art => {
            const isUser = art.innerText.startsWith('You\n') || art.querySelector('img[alt*="You"]') != null;
            const text = art.innerText?.replace(/^You\n/, '')?.trim() || '';
            const role = isUser ? 'user' : 'assistant';
            return JSON.stringify({ role: role, text: text });
        });
        GPTProTools.receiveCurrentConversation(JSON.stringify({ id: id, title: title, messages: messages }));
    } catch (e) {
        GPTProTools.reportError('Current conversation extraction failed: ' + e.message);
    }
})();
"""
