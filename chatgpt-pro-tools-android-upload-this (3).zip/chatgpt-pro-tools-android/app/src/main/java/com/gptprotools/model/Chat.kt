package com.gptprotools.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date
import java.util.UUID

/**
 * Represents a ChatGPT conversation.
 */
@Parcelize
data class Chat(
    val id: String = UUID.randomUUID().toString(),
    val externalId: String? = null, // ChatGPT conversation ID if available
    val title: String = "Untitled chat",
    val previewText: String = "",
    val createdAt: Date = Date(),
    val updatedAt: Date = Date(),
    val tags: MutableList<String> = mutableListOf(),
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val messages: List<ChatMessage> = emptyList()
) : Parcelable {
    val dateLabel: String
        get() = ChatRepository.dateFormatter.format(updatedAt)
}

/**
 * A single message inside a chat.
 */
@Parcelize
data class ChatMessage(
    val role: String, // "user" or "assistant" or "system"
    val text: String,
    val timestamp: Date = Date()
) : Parcelable

/**
 * In-memory repository used by the Chat Manager.
 * In the wrapper version, this is populated from the ChatGPT web DOM via JS injection.
 */
object ChatRepository {
    val dateFormatter = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())

    private val _chats = mutableListOf<Chat>()
    val chats: List<Chat> get() = _chats.toList()

    fun setAll(newChats: List<Chat>) {
        _chats.clear()
        _chats.addAll(newChats)
    }

    fun addOrUpdate(chat: Chat) {
        val index = _chats.indexOfFirst { it.externalId == chat.externalId && it.externalId != null }
        if (index >= 0) {
            _chats[index] = chat
        } else {
            _chats.add(chat)
        }
    }

    fun updateTags(externalId: String, tags: List<String>) {
        _chats.find { it.externalId == externalId }?.let {
            val idx = _chats.indexOf(it)
            _chats[idx] = it.copy(tags = tags.toMutableList())
        }
    }

    fun search(query: String, tags: List<String>, startDate: Date?, endDate: Date?): List<Chat> {
        val q = query.trim().lowercase()
        return _chats.filter { chat ->
            val matchesQuery = q.isEmpty() ||
                    chat.title.lowercase().contains(q) ||
                    chat.previewText.lowercase().contains(q) ||
                    chat.tags.any { it.lowercase().contains(q) }
            val matchesTags = tags.isEmpty() || chat.tags.any { it in tags }
            val afterStart = startDate?.let { chat.updatedAt >= it } ?: true
            val beforeEnd = endDate?.let { chat.updatedAt <= it } ?: true
            matchesQuery && matchesTags && afterStart && beforeEnd
        }.sortedWith(compareByDescending<Chat> { it.isPinned }.thenByDescending { it.updatedAt })
    }

    fun clear() = _chats.clear()

    fun remove(externalId: String) {
        _chats.removeAll { it.externalId == externalId }
    }
}
