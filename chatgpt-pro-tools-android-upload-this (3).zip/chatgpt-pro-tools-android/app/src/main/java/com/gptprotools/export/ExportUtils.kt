package com.gptprotools.export

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.gptprotools.model.Chat
import com.gptprotools.model.ChatMessage
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportUtils {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    fun chatToMarkdown(chat: Chat): String {
        val sb = StringBuilder()
        sb.appendLine("# ${chat.title}")
        sb.appendLine("_Exported on ${dateFormat.format(Date())}_")
        sb.appendLine()
        chat.messages.forEach { msg ->
            val label = if (msg.role == "user") "## You" else "## Assistant"
            sb.appendLine(label)
            sb.appendLine(msg.text)
            sb.appendLine()
        }
        return sb.toString()
    }

    fun chatToPlainText(chat: Chat): String {
        val sb = StringBuilder()
        sb.appendLine(chat.title)
        sb.appendLine("Exported on ${dateFormat.format(Date())}")
        sb.appendLine()
        chat.messages.forEach { msg ->
            val label = if (msg.role == "user") "You" else "Assistant"
            sb.appendLine("[$label]")
            sb.appendLine(msg.text)
            sb.appendLine()
        }
        return sb.toString()
    }

    /**
     * Exports a chat to a file using the given URI. Format is inferred from file extension.
     */
    fun exportToUri(context: Context, uri: Uri, chat: Chat, format: ExportFormat) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            OutputStreamWriter(out).use { writer ->
                when (format) {
                    ExportFormat.MARKDOWN -> writer.write(chatToMarkdown(chat))
                    ExportFormat.TXT -> writer.write(chatToPlainText(chat))
                    ExportFormat.PDF -> writer.write(chatToPlainText(chat)) // PDF handled separately via print
                }
            }
        }
    }

    /**
     * Print a chat to PDF using the Android PrintManager. A temporary WebView is used to render the HTML.
     */
    fun printToPdf(activity: Activity, chat: Chat, documentName: String = "Chat Export") {
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val webView = WebView(activity)
        webView.loadDataWithBaseURL(null, chatToHtml(chat), "text/HTML", "UTF-8", null)

        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val documentAdapter = webView.createPrintDocumentAdapter(documentName)
                printManager.print(documentName, documentAdapter, PrintAttributes.Builder().build())
            }
        }
    }

    private fun chatToHtml(chat: Chat): String {
        val body = StringBuilder()
        body.append("<h1>${escapeHtml(chat.title)}</h1>")
        body.append("<p><em>Exported on ${dateFormat.format(Date())}</em></p>")
        chat.messages.forEach { msg ->
            val label = if (msg.role == "user") "You" else "Assistant"
            body.append("<h3>${escapeHtml(label)}</h3>")
            body.append("<p>${escapeHtml(msg.text).replace("\n", "<br>")}</p>")
        }
        return """
            <html><head><meta name="viewport" content="width=device-width, initial-scale=1">
            <style>body{font-family: sans-serif; padding: 16px; max-width: 720px; margin: auto;} h1{color:#202124;} h3{color:#444;}</style>
            </head><body>$body</body></html>
        """.trimIndent()
    }

    private fun escapeHtml(input: String): String {
        return input.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    }

    fun createDocumentIntent(format: ExportFormat, fileName: String): Intent {
        return Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = when (format) {
                ExportFormat.MARKDOWN -> "text/markdown"
                ExportFormat.TXT -> "text/plain"
                ExportFormat.PDF -> "application/pdf"
            }
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
    }
}

enum class ExportFormat(val extension: String, val mime: String) {
    MARKDOWN("md", "text/markdown"),
    TXT("txt", "text/plain"),
    PDF("pdf", "application/pdf")
}

/**
 * Composable helper to launch the Storage Access Framework picker for exporting a chat.
 */
@Composable
fun rememberExportLauncher(
    onUriSelected: (Uri) -> Unit
): androidx.activity.result.ActivityResultLauncher<Intent> {
    val context = LocalContext.current
    return rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                onUriSelected(uri)
            }
        }
    }
}

fun ChatMessage.preview(): String = text.take(300)
