package com.gptprotools.ai

import android.content.Context
import com.gptprotools.model.Chat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

interface AiTagger {
    suspend fun suggestTags(chats: List<Chat>): Map<String, List<String>>
    suspend fun suggestTags(chat: Chat): List<String>
    fun available(): Boolean
}

/**
 * Factory that returns an on-device or fallback tagger.
 */
object AiTaggerFactory {
    fun create(context: Context): AiTagger {
        // To use real on-device AI, uncomment and configure MediaPipeLlmTagger below.
        // For a working demo out of the box, we use the keyword fallback.
        return KeywordFallbackTagger()
    }
}

/**
 * Lightweight, fully offline tagger using keyword heuristics.
 * Works on every device without downloading a model.
 */
class KeywordFallbackTagger : AiTagger {

    private val vocabulary = listOf(
        "coding" to listOf("code", "kotlin", "java", "python", "javascript", "error", "bug", "function", "api", "debug", "compile", "git"),
        "writing" to listOf("essay", "blog", "draft", "email", "story", "copy", "tone", "edit"),
        "business" to listOf("strategy", "plan", "market", "revenue", "customer", "product", "sales", "meeting"),
        "learning" to listOf("explain", "tutorial", "learn", "course", "study", "concept", "how to"),
        "creative" to listOf("idea", "design", "image", "art", "dalle", "music", "brainstorm"),
        "data" to listOf("csv", "json", "analysis", "chart", "sql", "dataset", "statistics"),
        "support" to listOf("help", "issue", "troubleshoot", "fix", "problem", "question"),
        "legal" to listOf("contract", "terms", "privacy", "law", "compliance", "policy"),
        "health" to listOf("workout", "diet", "symptom", "mental", "medical", "nutrition"),
        "travel" to listOf("trip", "flight", "hotel", "itinerary", "vacation", "visit"),
        "finance" to listOf("budget", "invest", "stock", "tax", "money", "expense"),
        "recipes" to listOf("recipe", "cook", "ingredient", "meal", "food")
    )

    override fun available(): Boolean = true

    override suspend fun suggestTags(chats: List<Chat>): Map<String, List<String>> = withContext(Dispatchers.Default) {
        chats.associate { chat ->
            chat.externalId ?: chat.id to suggestTags(chat)
        }
    }

    override suspend fun suggestTags(chat: Chat): List<String> = withContext(Dispatchers.Default) {
        val text = buildString {
            append(chat.title.lowercase()).append(" ")
            append(chat.previewText.lowercase()).append(" ")
            chat.messages.forEach { append(it.text.lowercase()).append(" ") }
        }
        val matched = vocabulary.mapNotNull { (tag, keywords) ->
            if (keywords.any { text.contains(it) }) tag else null
        }
        if (matched.isEmpty()) listOf("general") else matched
    }
}

/**
 * Real on-device generative AI tagger using MediaPipe LLM Inference.
 *
 * Requirements:
 * 1. Add dependency: implementation("com.google.mediapipe:tasks-genai:0.10.14")
 * 2. Download a small model (e.g., Gemma 2B IT) from Kaggle/Hugging Face.
 * 3. Place the .bin file in assets/ or Download directory and update modelPath below.
 * 4. Replace AiTaggerFactory.create() with MediaPipeLlmTagger(context, modelPath).
 */
/*
class MediaPipeLlmTagger(context: Context, private val modelPath: String) : AiTagger {

    private var llmInference: com.google.mediapipe.tasks.genai.llminference.LlmInference? = null

    init {
        try {
            val options = com.google.mediapipe.tasks.genai.llminference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(512)
                .setTopK(40)
                .setTemperature(0.8f)
                .setRandomSeed(101)
                .build()
            llmInference = com.google.mediapipe.tasks.genai.llminference.LlmInference.createFromOptions(context, options)
        } catch (e: Exception) {
            android.util.Log.e("AiTagger", "MediaPipe init failed", e)
        }
    }

    override fun available(): Boolean = llmInference != null

    override suspend fun suggestTags(chats: List<Chat>): Map<String, List<String>> {
        return chats.associate { chat ->
            chat.externalId ?: chat.id to suggestTags(chat)
        }
    }

    override suspend fun suggestTags(chat: Chat): List<String> = withContext(Dispatchers.IO) {
        if (!available()) return@withContext emptyList<String>()
        val prompt = buildPrompt(chat)
        val response = llmInference?.generateResponse(prompt) ?: return@withContext emptyList<String>()
        parseTags(response)
    }

    private fun buildPrompt(chat: Chat): String {
        return """
            You are an organizer. Given a ChatGPT conversation title and first lines, return a JSON array of 1-3 short lowercase tags (no spaces). Examples: ["coding", "kotlin", "debugging"].

            Title: ${chat.title}
            Preview: ${chat.previewText.take(300)}

            Tags:
        """.trimIndent()
    }

    private fun parseTags(response: String): List<String> {
        val regex = """\"([^\"]+)\"""".toRegex()
        return regex.findAll(response).map { it.groupValues[1] }.filter { it.isNotBlank() }.take(3).toList()
    }
}
*/
