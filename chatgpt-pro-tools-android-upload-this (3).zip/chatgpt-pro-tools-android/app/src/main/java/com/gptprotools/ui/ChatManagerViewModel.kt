package com.gptprotools.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gptprotools.ai.AiTaggerFactory
import com.gptprotools.model.Chat
import com.gptprotools.model.ChatRepository
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

class ChatManagerViewModel(application: Application) : AndroidViewModel(application) {

    private val aiTagger = AiTaggerFactory.create(application)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedTags = MutableStateFlow<List<String>>(emptyList())
    val selectedTags: StateFlow<List<String>> = _selectedTags

    private val _startDate = MutableStateFlow<Date?>(null)
    val startDate: StateFlow<Date?> = _startDate

    private val _endDate = MutableStateFlow<Date?>(null)
    val endDate: StateFlow<Date?> = _endDate

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _showPanel = MutableStateFlow(false)
    val showPanel: StateFlow<Boolean> = _showPanel

    private val _navigateToChat = Channel<String>(Channel.BUFFERED)
    val navigateToChat = _navigateToChat.receiveAsFlow()

    val filteredChats: StateFlow<List<Chat>> = combine(
        _searchQuery,
        _selectedTags,
        _startDate,
        _endDate
    ) { query, tags, start, end ->
        ChatRepository.search(query, tags, start, end)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _allTags = MutableStateFlow<List<String>>(emptyList())
    val allTags: StateFlow<List<String>> = _allTags

    init {
        refreshAllTags()
    }

    fun togglePanel() {
        _showPanel.value = !_showPanel.value
    }

    fun setPanelVisible(visible: Boolean) {
        _showPanel.value = visible
    }

    fun navigateToChat(chatId: String) {
        viewModelScope.launch {
            _navigateToChat.send(chatId)
        }
    }

    fun onSearch(query: String) {
        _searchQuery.value = query
    }

    fun toggleTag(tag: String) {
        _selectedTags.value = if (tag in _selectedTags.value) {
            _selectedTags.value - tag
        } else {
            _selectedTags.value + tag
        }
    }

    fun setDateRange(start: Date?, end: Date?) {
        _startDate.value = start
        _endDate.value = end
    }

    fun clearFilters() {
        _searchQuery.value = ""
        _selectedTags.value = emptyList()
        _startDate.value = null
        _endDate.value = null
    }

    fun loadChats(chats: List<Chat>) {
        ChatRepository.setAll(chats)
        refreshAllTags()
    }

    fun addOrUpdateChat(chat: Chat) {
        ChatRepository.addOrUpdate(chat)
        refreshAllTags()
    }

    fun generateAiTags() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val suggestions = aiTagger.suggestTags(ChatRepository.chats)
                suggestions.forEach { (id, tags) ->
                    ChatRepository.updateTags(id, tags)
                }
                refreshAllTags()
            } catch (e: Exception) {
                _errorMessage.value = "AI tagging failed: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun addTagToChat(chatId: String, tag: String) {
        ChatRepository.updateTags(chatId, ChatRepository.chats.find { it.externalId == chatId || it.id == chatId }?.tags?.plus(tag)?.distinct() ?: listOf(tag))
        refreshAllTags()
    }

    fun removeTagFromChat(chatId: String, tag: String) {
        ChatRepository.updateTags(chatId, ChatRepository.chats.find { it.externalId == chatId || it.id == chatId }?.tags?.minus(tag) ?: emptyList())
        refreshAllTags()
    }

    fun deleteChat(chatId: String) {
        ChatRepository.remove(chatId)
        refreshAllTags()
    }

    fun pinChat(chatId: String) {
        // Repository doesn't have pin support; simplified here.
    }

    fun refreshAllTags() {
        _allTags.value = ChatRepository.chats.flatMap { it.tags }.distinct().sorted()
    }

    fun dismissError() {
        _errorMessage.value = null
    }

    fun reportError(message: String) {
        _errorMessage.value = message
    }

    fun setStartDate(year: Int, month: Int, day: Int) {
        val cal = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0) }
        _startDate.value = cal.time
    }

    fun setEndDate(year: Int, month: Int, day: Int) {
        val cal = Calendar.getInstance().apply { set(year, month, day, 23, 59, 59) }
        _endDate.value = cal.time
    }
}
