package com.gptprotools.ui

import android.app.Activity
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gptprotools.export.ExportFormat
import com.gptprotools.export.ExportUtils
import com.gptprotools.export.rememberExportLauncher
import com.gptprotools.model.Chat
import java.util.Calendar
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChatManagerPanel(
    viewModel: ChatManagerViewModel = viewModel(),
    onChatSelected: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val showPanel by viewModel.showPanel.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val selectedTags by viewModel.selectedTags.collectAsState()
    val allTags by viewModel.allTags.collectAsState()
    val filteredChats by viewModel.filteredChats.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.errorMessage.collectAsState()
    val startDate by viewModel.startDate.collectAsState()
    val endDate by viewModel.endDate.collectAsState()

    var showAddTagDialog by remember { mutableStateOf<Chat?>(null) }
    var showExportDialog by remember { mutableStateOf<Chat?>(null) }
    var showDeleteConfirm by remember { mutableStateOf<Chat?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    var datePickerMode by remember { mutableStateOf<DatePickerMode?>(null) }

    val exportLauncher = rememberExportLauncher { uri ->
        showExportDialog?.let { chat ->
            val format = when {
                uri.path?.endsWith(".md") == true -> ExportFormat.MARKDOWN
                uri.path?.endsWith(".txt") == true -> ExportFormat.TXT
                else -> ExportFormat.TXT
            }
            ExportUtils.exportToUri(context, uri, chat, format)
            showExportDialog = null
        }
    }

    val printPdf: (Chat) -> Unit = { chat ->
        (context as? Activity)?.let { activity ->
            ExportUtils.printToPdf(activity, chat, "${chat.title}.pdf")
        }
    }

    error?.let { msg ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissError() },
            confirmButton = { TextButton(onClick = { viewModel.dismissError() }) { Text("OK") } },
            title = { Text("Info") },
            text = { Text(msg) }
        )
    }

    showAddTagDialog?.let { chat ->
        AddTagDialog(
            existingTags = chat.tags,
            allTags = allTags,
            onDismiss = { showAddTagDialog = null },
            onAdd = { tag ->
                viewModel.addTagToChat(chat.externalId ?: chat.id, tag)
                showAddTagDialog = null
            }
        )
    }

    showDeleteConfirm?.let { chat ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = null },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteChat(chat.externalId ?: chat.id); showDeleteConfirm = null }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = null }) { Text("Cancel") } },
            title = { Text("Delete chat?") },
            text = { Text("This will remove the chat from the local list only. It does not delete it on ChatGPT.") }
        )
    }

    showExportDialog?.let { chat ->
        ExportDialog(
            chat = chat,
            onDismiss = { showExportDialog = null },
            onFormatSelected = { format ->
                if (format == ExportFormat.PDF) {
                    printPdf(chat)
                    showExportDialog = null
                } else {
                    val intent = ExportUtils.createDocumentIntent(
                        format,
                        "${chat.title}.${format.extension}"
                    )
                    exportLauncher.launch(intent)
                }
            }
        )
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = when (datePickerMode) {
                DatePickerMode.START -> startDate?.time
                DatePickerMode.END -> endDate?.time
                else -> System.currentTimeMillis()
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        val cal = Calendar.getInstance().apply { timeInMillis = millis }
                        when (datePickerMode) {
                            DatePickerMode.START -> viewModel.setStartDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
                            DatePickerMode.END -> viewModel.setEndDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
                            else -> {}
                        }
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = showPanel,
            enter = slideInHorizontally(initialOffsetX = { -it }),
            exit = slideOutHorizontally(targetOffsetX = { -it }),
            modifier = Modifier
                .fillMaxHeight()
                .width(360.dp)
                .align(Alignment.TopStart)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chat Manager",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { viewModel.setPanelVisible(false) }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = viewModel::onSearch,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search chats") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { viewModel.onSearch("") }) {
                                Icon(Icons.Default.Clear, null)
                            }
                        }
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            datePickerMode = DatePickerMode.START
                            showDatePicker = true
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.DateRange, null)
                        Spacer(Modifier.width(4.dp))
                        Text(startDate?.let { formatDate(it) } ?: "From", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = {
                            datePickerMode = DatePickerMode.END
                            showDatePicker = true
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.DateRange, null)
                        Spacer(Modifier.width(4.dp))
                        Text(endDate?.let { formatDate(it) } ?: "To", maxLines = 1)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (allTags.isNotEmpty()) {
                    Text("Tags", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        allTags.forEach { tag ->
                            FilterChip(
                                selected = tag in selectedTags,
                                onClick = { viewModel.toggleTag(tag) },
                                label = { Text(tag) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.generateAiTags() },
                        modifier = Modifier.weight(1f),
                        enabled = !isLoading
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        } else {
                            Text("AI Tag All")
                        }
                    }
                    OutlinedButton(
                        onClick = { viewModel.clearFilters() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "${filteredChats.size} chats",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredChats, key = { it.id }) { chat ->
                        ChatCard(
                            chat = chat,
                            onClick = {
                                onChatSelected(chat.externalId ?: chat.id)
                                viewModel.setPanelVisible(false)
                            },
                            onAddTag = { showAddTagDialog = chat },
                            onRemoveTag = { tag -> viewModel.removeTagFromChat(chat.externalId ?: chat.id, tag) },
                            onExport = { showExportDialog = chat },
                            onDelete = { showDeleteConfirm = chat }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChatCard(
    chat: Chat,
    onClick: () -> Unit,
    onAddTag: () -> Unit,
    onRemoveTag: (String) -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = chat.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
            Text(
                text = chat.previewText.ifEmpty { "No preview available" },
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = chat.dateLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                chat.tags.forEach { tag ->
                    TagChip(tag = tag, onRemove = { onRemoveTag(tag) })
                }
                TagChip(tag = "+", onClick = onAddTag, isAdd = true)
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(onClick = onExport, modifier = Modifier.align(Alignment.End)) {
                Text("Export")
            }
        }
    }
}

@Composable
private fun TagChip(tag: String, onRemove: (() -> Unit)? = null, onClick: (() -> Unit)? = null, isAdd: Boolean = false) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isAdd) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer)
            .clickable(enabled = onClick != null, onClick = onClick ?: {})
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = tag,
                style = MaterialTheme.typography.labelMedium,
                color = if (isAdd) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer
            )
            if (onRemove != null && !isAdd) {
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove tag",
                    modifier = Modifier
                        .clickable(onClick = onRemove)
                        .width(14.dp)
                        .height(14.dp),
                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}

@Composable
private fun AddTagDialog(
    existingTags: List<String>,
    allTags: List<String>,
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit
) {
    var newTag by remember { mutableStateOf("") }
    val suggestions = remember(newTag, allTags) {
        allTags.filter { it !in existingTags && it.contains(newTag, ignoreCase = true) && newTag.isNotBlank() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = { if (newTag.isNotBlank()) onAdd(newTag.trim().lowercase()) },
                enabled = newTag.isNotBlank()
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("Add tag") },
        text = {
            Column {
                OutlinedTextField(
                    value = newTag,
                    onValueChange = { newTag = it.lowercase().replace(" ", "-") },
                    label = { Text("Tag name") },
                    singleLine = true
                )
                if (suggestions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Suggestions", style = MaterialTheme.typography.labelMedium)
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        suggestions.forEach { tag ->
                            Text(
                                text = tag,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onAdd(tag) }
                                    .padding(vertical = 8.dp),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    )
}

@Composable
private fun ExportDialog(
    chat: Chat,
    onDismiss: () -> Unit,
    onFormatSelected: (ExportFormat) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text("Export ${chat.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExportFormat.entries.forEach { format ->
                    Button(
                        onClick = { onFormatSelected(format) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(format.name.uppercase())
                    }
                }
            }
        }
    )
}

private fun formatDate(date: Date): String {
    val fmt = java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.getDefault())
    return fmt.format(date)
}

private enum class DatePickerMode { START, END }
