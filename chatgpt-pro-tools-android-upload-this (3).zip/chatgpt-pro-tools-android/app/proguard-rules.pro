# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.

# Keep JavaScript interface class for WebView bridge.
-keepclassmembers class com.gptprotools.bridge.JavaScriptBridge {
    @android.webkit.JavascriptInterface <methods>;
}
